'use client';

import { motion } from 'framer-motion';
import React, { useState } from 'react';

const portfolioProjects = [
  {
    id: 1,
    title: 'E-commerce de Alta Gama',
    category: 'Desarrollo Web',
    description: 'Plataforma de e-commerce premium con IA personalizada',
    image: '🛍️',
    technologies: ['React', 'Node.js', 'TailwindCSS', 'IA'],
    results: '+150% en conversiones',
  },
  {
    id: 2,
    title: 'Chatbot de Atención al Cliente',
    category: 'IA',
    description: 'Asistente virtual inteligente con procesamiento de lenguaje natural',
    image: '🤖',
    technologies: ['Python', 'NLP', 'React', 'WebSocket'],
    results: '90% satisfacción',
  },
  {
    id: 3,
    title: 'Sistema de Automatización Empresarial',
    category: 'Automatización',
    description: 'Software que automatiza procesos complejos de negocios',
    image: '⚙️',
    technologies: ['Next.js', 'TypeScript', 'PostgreSQL', 'API REST'],
    results: '-60% tiempo manual',
  },
  {
    id: 4,
    title: 'Plataforma SaaS de Análisis',
    category: 'Desarrollo Web',
    description: 'Dashboard de análisis en tiempo real con visualizaciones avanzadas',
    image: '📊',
    technologies: ['React', 'D3.js', 'Node.js', 'MongoDB'],
    results: '+200% productividad',
  },
  {
    id: 5,
    title: 'Sistema de Marketing IA',
    category: 'IA',
    description: 'Plataforma que automatiza campañas de marketing con IA',
    image: '📢',
    technologies: ['Python', 'Machine Learning', 'React', 'Firebase'],
    results: '+300% ROI',
  },
  {
    id: 6,
    title: 'App Móvil Empresarial',
    category: 'Desarrollo Web',
    description: 'Aplicación móvil con sincronización en tiempo real',
    image: '📱',
    technologies: ['React Native', 'Firebase', 'GraphQL', 'Redux'],
    results: '+500K usuarios',
  },
];

const categories = ['Todos', 'Desarrollo Web', 'IA', 'Automatización'];

export default function PortfolioSection() {
  const [selectedCategory, setSelectedCategory] = useState('Todos');

  const filteredProjects =
    selectedCategory === 'Todos'
      ? portfolioProjects
      : portfolioProjects.filter((p) => p.category === selectedCategory);

  return (
    <section className="relative py-24 bg-vanyx-black overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/3 right-0 w-96 h-96 bg-vanyx-cyan/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-vanyx-cyan/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Nuestro Portafolio
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Proyectos exitosos que demuestran nuestra expertise en tecnología
          </p>
        </motion.div>

        {/* Filter buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="flex flex-wrap gap-4 justify-center mb-16"
        >
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setSelectedCategory(category)}
              className={`px-6 py-3 rounded-full font-semibold transition-all duration-300 ${
                selectedCategory === category
                  ? 'bg-vanyx-cyan text-vanyx-black'
                  : 'border border-vanyx-cyan/40 text-vanyx-cyan hover:border-vanyx-cyan/80'
              }`}
            >
              {category}
            </motion.button>
          ))}
        </motion.div>

        {/* Projects grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="group"
            >
              <div className="relative h-full rounded-xl overflow-hidden border border-vanyx-gray/50 bg-gradient-to-br from-vanyx-gray/20 to-vanyx-black/50 backdrop-blur-xl hover:border-vanyx-cyan/50 transition-all duration-300 cursor-pointer">
                {/* Top glow on hover */}
                <div className="absolute inset-0 bg-gradient-to-b from-vanyx-cyan/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />

                {/* Content */}
                <div className="relative p-8 h-full flex flex-col justify-between">
                  {/* Top section */}
                  <div>
                    {/* Image placeholder */}
                    <div className="mb-6 flex items-center justify-center h-24 rounded-lg bg-gradient-to-br from-vanyx-cyan/20 to-vanyx-gray/20 group-hover:from-vanyx-cyan/40 group-hover:to-vanyx-gray/40 transition-all duration-300">
                      <span className="text-6xl">{project.image}</span>
                    </div>

                    {/* Category tag */}
                    <div className="mb-3 inline-block">
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-vanyx-cyan/20 text-vanyx-cyan">
                        {project.category}
                      </span>
                    </div>

                    {/* Title */}
                    <h3 className="text-xl font-bold text-white mb-3 group-hover:text-vanyx-cyan transition-colors duration-300">
                      {project.title}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-gray-400 mb-4">{project.description}</p>

                    {/* Results badge */}
                    <div className="mb-4 inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-vanyx-cyan/10 border border-vanyx-cyan/30">
                      <span className="text-vanyx-cyan text-xs font-semibold">{project.results}</span>
                    </div>
                  </div>

                  {/* Technologies */}
                  <div className="border-t border-vanyx-gray/50 pt-4 mt-4">
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech, i) => (
                        <span
                          key={i}
                          className="px-2 py-1 rounded text-xs bg-vanyx-gray/50 text-gray-300 font-medium"
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Hover action */}
                  <motion.div
                    initial={{ opacity: 0 }}
                    whileHover={{ opacity: 1 }}
                    className="absolute bottom-4 right-4 flex items-center justify-center w-10 h-10 rounded-full bg-vanyx-cyan text-vanyx-black group-hover:scale-110 transition-transform duration-300"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        strokeWidth={2}
                        d="M13 7l5 5m0 0l-5 5m5-5H6"
                      />
                    </svg>
                  </motion.div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-20 text-center"
        >
          <p className="text-gray-400 mb-6">¿Quieres ver más casos de éxito?</p>
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(0, 217, 255, 0.4)' }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 rounded-lg font-semibold text-vanyx-black bg-vanyx-cyan hover:bg-vanyx-cyan-light transition-all duration-300"
          >
            Ver todos los proyectos
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
