'use client';

import { motion } from 'framer-motion';
import React from 'react';

export default function AboutSection() {
  const stats = [
    { label: 'Proyectos Completados', value: '50+', icon: '✓' },
    { label: 'Clientes Satisfechos', value: '30+', icon: '👥' },
    { label: 'Años de Experiencia', value: '5+', icon: '⭐' },
    { label: 'Tecnologías Dominadas', value: '20+', icon: '🚀' },
  ];

  const values = [
    {
      title: 'Innovación',
      description: 'Siempre a la vanguardia de la tecnología y las mejores prácticas.',
      icon: '💡',
    },
    {
      title: 'Calidad',
      description: 'Entregables de la más alta calidad que superan expectativas.',
      icon: '⚡',
    },
    {
      title: 'Confiabilidad',
      description: 'Tu socio tecnológico 24/7 disponible cuando lo necesites.',
      icon: '🛡️',
    },
    {
      title: 'Escalabilidad',
      description: 'Soluciones que crecen con tu negocio sin limitaciones.',
      icon: '📈',
    },
  ];

  return (
    <section className="relative py-24 bg-vanyx-black overflow-hidden">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-5">
        <div
          style={{
            backgroundImage: `
              linear-gradient(0deg, transparent 24%, rgba(0, 217, 255, 0.1) 25%, rgba(0, 217, 255, 0.1) 26%, transparent 27%, transparent 74%, rgba(0, 217, 255, 0.1) 75%, rgba(0, 217, 255, 0.1) 76%, transparent 77%, transparent),
              linear-gradient(90deg, transparent 24%, rgba(0, 217, 255, 0.1) 25%, rgba(0, 217, 255, 0.1) 26%, transparent 27%, transparent 74%, rgba(0, 217, 255, 0.1) 75%, rgba(0, 217, 255, 0.1) 76%, transparent 77%, transparent)
            `,
            backgroundSize: '100px 100px',
          }}
          className="absolute inset-0"
        />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-20 text-center"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Sobre VANYX
          </h2>
          <p className="text-lg text-gray-400 max-w-3xl mx-auto">
            Somos un equipo de expertos en tecnología dedicados a transformar negocios a través
            de soluciones innovadoras, escalables y confiables.
          </p>
        </motion.div>

        {/* Main content grid */}
        <div className="grid md:grid-cols-2 gap-12 mb-20 items-center">
          {/* Left column - Text */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <h3 className="text-3xl font-bold text-white mb-6">Nuestra Visión</h3>
            <p className="text-gray-400 mb-6 leading-relaxed">
              En VANYX, creemos que la tecnología debe ser accesible, poderosa y capaz de
              transformar cualquier negocio, sin importar su tamaño.
            </p>
            <p className="text-gray-400 mb-8 leading-relaxed">
              Con un equipo de expertos en desarrollo web, inteligencia artificial, automatización
              y ciberseguridad, nos dedicamos a crear soluciones que no solo resuelven problemas,
              sino que abren nuevas oportunidades de crecimiento.
            </p>

            {/* Features list */}
            <div className="space-y-4">
              {[
                'Equipo multidisciplinario de expertos',
                'Enfoque centrado en el cliente',
                'Tecnología de punta y actualizada',
                'Soluciones escalables y sostenibles',
              ].map((feature, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="flex items-center gap-3"
                >
                  <div className="flex-shrink-0 w-6 h-6 rounded-full bg-vanyx-cyan/20 border border-vanyx-cyan flex items-center justify-center">
                    <svg className="w-4 h-4 text-vanyx-cyan" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <span className="text-gray-300">{feature}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right column - Visual element */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-gradient-to-br from-vanyx-cyan/10 to-transparent rounded-2xl blur-2xl" />
            <div className="relative p-12 rounded-2xl border border-vanyx-cyan/30 bg-gradient-to-br from-vanyx-gray/20 to-vanyx-black/50 backdrop-blur-xl">
              <div className="grid grid-cols-2 gap-6">
                {stats.map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="text-center p-6 rounded-lg border border-vanyx-gray/50 bg-vanyx-black/50 hover:border-vanyx-cyan/50 hover:bg-vanyx-cyan/5 transition-all duration-300"
                  >
                    <div className="text-4xl mb-2">{stat.icon}</div>
                    <div className="text-3xl font-bold text-vanyx-cyan mb-2">{stat.value}</div>
                    <div className="text-sm text-gray-400">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>

        {/* Values section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mb-20"
        >
          <h3 className="text-3xl font-bold text-white mb-12 text-center">Nuestros Valores</h3>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -5 }}
                className="p-8 rounded-xl border border-vanyx-gray/50 bg-gradient-to-br from-vanyx-gray/20 to-vanyx-black/50 backdrop-blur-xl hover:border-vanyx-cyan/50 transition-all duration-300"
              >
                <div className="text-4xl mb-4">{value.icon}</div>
                <h4 className="text-xl font-bold text-white mb-3">{value.title}</h4>
                <p className="text-gray-400 text-sm leading-relaxed">{value.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center bg-gradient-to-r from-vanyx-cyan/10 to-transparent rounded-2xl border border-vanyx-cyan/30 p-12"
        >
          <h3 className="text-2xl font-bold text-white mb-4">¿Listo para transformar tu negocio?</h3>
          <p className="text-gray-400 mb-8 max-w-2xl mx-auto">
            Contáctanos hoy y descubre cómo VANYX puede ayudarte a alcanzar tus objetivos.
          </p>
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(0, 217, 255, 0.4)' }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 rounded-lg font-semibold text-vanyx-black bg-vanyx-cyan hover:bg-vanyx-cyan-light transition-all duration-300"
          >
            Comenzar ahora
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
