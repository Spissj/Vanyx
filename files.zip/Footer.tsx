'use client';

import { motion } from 'framer-motion';
import React from 'react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const footerLinks = {
    Producto: [
      { label: 'Servicios', href: '#servicios' },
      { label: 'Portafolio', href: '#portafolio' },
      { label: 'Tecnologías', href: '#' },
      { label: 'Precios', href: '#' },
    ],
    Empresa: [
      { label: 'Sobre Nosotros', href: '#sobre-nosotros' },
      { label: 'Blog', href: '#' },
      { label: 'Carreras', href: '#' },
      { label: 'Contacto', href: '#contacto' },
    ],
    Legal: [
      { label: 'Política de Privacidad', href: '#' },
      { label: 'Términos de Servicio', href: '#' },
      { label: 'Cookies', href: '#' },
    ],
    Social: [
      { label: 'GitHub', href: '#', icon: '🐙' },
      { label: 'LinkedIn', href: '#', icon: '💼' },
      { label: 'Twitter', href: '#', icon: '𝕏' },
      { label: 'Instagram', href: '#', icon: '📷' },
    ],
  };

  return (
    <footer className="relative bg-vanyx-black border-t border-vanyx-gray/20 overflow-hidden">
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-1/2 w-96 h-96 bg-vanyx-cyan/5 rounded-full blur-3xl -translate-x-1/2" />
      </div>

      <div className="relative z-10">
        {/* Main footer content */}
        <div className="mx-auto max-w-7xl px-6 py-16">
          <div className="grid md:grid-cols-5 gap-12 mb-12">
            {/* Brand column */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <div className="flex items-center gap-2 mb-6">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-vanyx-cyan to-cyan-500 flex items-center justify-center">
                  <span className="text-white font-bold text-lg">V</span>
                </div>
                <span className="text-xl font-bold text-white">VANYX</span>
              </div>
              <p className="text-sm text-gray-400 mb-6 leading-relaxed">
                Transformamos la visión de tu negocio en realidad con tecnología avanzada e innovación.
              </p>
              <div className="flex gap-4">
                {footerLinks.Social.map((item) => (
                  <motion.a
                    key={item.label}
                    href={item.href}
                    whileHover={{ scale: 1.2, color: '#00D9FF' }}
                    whileTap={{ scale: 0.9 }}
                    className="w-10 h-10 rounded-full border border-vanyx-gray/50 flex items-center justify-center text-gray-400 hover:border-vanyx-cyan/50 hover:text-vanyx-cyan transition-all duration-300"
                    title={item.label}
                  >
                    {item.icon}
                  </motion.a>
                ))}
              </div>
            </motion.div>

            {/* Links columns */}
            {Object.entries(footerLinks).slice(0, 3).map(([category, links]) => (
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.1 }}
              >
                <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-6">
                  {category}
                </h3>
                <ul className="space-y-4">
                  {links.map((link) => (
                    <li key={link.label}>
                      <motion.a
                        href={link.href}
                        whileHover={{ x: 5, color: '#00D9FF' }}
                        className="text-sm text-gray-400 hover:text-vanyx-cyan transition-all duration-300"
                      >
                        {link.label}
                      </motion.a>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>

          {/* Divider */}
          <div className="h-px bg-gradient-to-r from-vanyx-gray/0 via-vanyx-gray/50 to-vanyx-gray/0 mb-8" />

          {/* Bottom section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="flex flex-col md:flex-row items-center justify-between gap-6 text-sm text-gray-400"
          >
            <p>
              © {currentYear} VANYX. Todos los derechos reservados. Hecho con{' '}
              <span className="text-vanyx-cyan">💙</span> en Chile
            </p>

            <div className="flex gap-6">
              {footerLinks.Legal.map((link) => (
                <motion.a
                  key={link.label}
                  href={link.href}
                  whileHover={{ color: '#00D9FF' }}
                  className="hover:text-vanyx-cyan transition-colors duration-300"
                >
                  {link.label}
                </motion.a>
              ))}
            </div>
          </motion.div>

          {/* Floating CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-12 p-6 rounded-xl border border-vanyx-cyan/30 bg-gradient-to-r from-vanyx-cyan/10 to-transparent text-center"
          >
            <p className="text-gray-300 mb-4">
              ¿Listo para revolucionar tu negocio?
            </p>
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(0, 217, 255, 0.3)' }}
              whileTap={{ scale: 0.95 }}
              className="px-6 py-2 rounded-lg font-semibold text-vanyx-black bg-vanyx-cyan hover:bg-vanyx-cyan-light transition-all duration-300 text-sm"
            >
              Agendar llamada
            </motion.button>
          </motion.div>
        </div>
      </div>
    </footer>
  );
}
