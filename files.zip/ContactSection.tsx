'use client';

import { motion } from 'framer-motion';
import React, { useState } from 'react';

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    service: '',
    message: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Simulate form submission
      await new Promise((resolve) => setTimeout(resolve, 1500));
      setSubmitStatus('success');
      setFormData({ name: '', email: '', company: '', service: '', message: '' });

      // Reset status after 3 seconds
      setTimeout(() => setSubmitStatus('idle'), 3000);
    } catch (error) {
      setSubmitStatus('error');
      setTimeout(() => setSubmitStatus('idle'), 3000);
    } finally {
      setIsSubmitting(false);
    }
  };

  const contactMethods = [
    {
      icon: '📧',
      label: 'Email',
      value: 'hola@vanyx.com',
      link: 'mailto:hola@vanyx.com',
    },
    {
      icon: '💬',
      label: 'WhatsApp',
      value: '+56 9 1234 5678',
      link: 'https://wa.me/56912345678',
    },
    {
      icon: '📍',
      label: 'Ubicación',
      value: 'Santiago, Chile',
      link: '#',
    },
    {
      icon: '⏰',
      label: 'Horario',
      value: 'Lun - Vie 9:00 - 18:00',
      link: '#',
    },
  ];

  return (
    <section className="relative py-24 bg-vanyx-black overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-vanyx-cyan/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-vanyx-cyan/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Conectemos
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            ¿Listo para transformar tu negocio? Contáctanos hoy y conversemos sobre tus necesidades
          </p>
        </motion.div>

        {/* Contact methods */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
        >
          {contactMethods.map((method, index) => (
            <motion.a
              key={index}
              href={method.link}
              target={method.link.startsWith('http') ? '_blank' : '_self'}
              rel={method.link.startsWith('http') ? 'noopener noreferrer' : ''}
              whileHover={{ y: -5 }}
              className="p-6 rounded-xl border border-vanyx-gray/50 bg-gradient-to-br from-vanyx-gray/20 to-vanyx-black/50 backdrop-blur-xl hover:border-vanyx-cyan/50 hover:bg-vanyx-cyan/5 transition-all duration-300 text-center"
            >
              <div className="text-4xl mb-3">{method.icon}</div>
              <h3 className="font-semibold text-white mb-2">{method.label}</h3>
              <p className="text-sm text-gray-400 hover:text-vanyx-cyan transition-colors">
                {method.value}
              </p>
            </motion.a>
          ))}
        </motion.div>

        {/* Main contact form section */}
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
          >
            <div className="p-8 rounded-2xl border border-vanyx-cyan/30 bg-gradient-to-br from-vanyx-gray/20 to-vanyx-black/50 backdrop-blur-xl">
              <h3 className="text-2xl font-bold text-white mb-8">Envíanos un mensaje</h3>

              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name */}
                <div>
                  <label htmlFor="name" className="block text-sm font-semibold text-gray-300 mb-3">
                    Nombre
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 rounded-lg bg-vanyx-gray/50 border border-vanyx-gray/80 text-white placeholder-gray-500 focus:outline-none focus:border-vanyx-cyan focus:ring-1 focus:ring-vanyx-cyan transition-all duration-300"
                    placeholder="Tu nombre"
                  />
                </div>

                {/* Email */}
                <div>
                  <label htmlFor="email" className="block text-sm font-semibold text-gray-300 mb-3">
                    Email
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 rounded-lg bg-vanyx-gray/50 border border-vanyx-gray/80 text-white placeholder-gray-500 focus:outline-none focus:border-vanyx-cyan focus:ring-1 focus:ring-vanyx-cyan transition-all duration-300"
                    placeholder="tu@email.com"
                  />
                </div>

                {/* Company */}
                <div>
                  <label htmlFor="company" className="block text-sm font-semibold text-gray-300 mb-3">
                    Empresa
                  </label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg bg-vanyx-gray/50 border border-vanyx-gray/80 text-white placeholder-gray-500 focus:outline-none focus:border-vanyx-cyan focus:ring-1 focus:ring-vanyx-cyan transition-all duration-300"
                    placeholder="Tu empresa"
                  />
                </div>

                {/* Service */}
                <div>
                  <label htmlFor="service" className="block text-sm font-semibold text-gray-300 mb-3">
                    Servicio de interés
                  </label>
                  <select
                    id="service"
                    name="service"
                    value={formData.service}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 rounded-lg bg-vanyx-gray/50 border border-vanyx-gray/80 text-white focus:outline-none focus:border-vanyx-cyan focus:ring-1 focus:ring-vanyx-cyan transition-all duration-300"
                  >
                    <option value="">Selecciona un servicio</option>
                    <option value="desarrollo-web">Desarrollo Web</option>
                    <option value="automatizacion-ia">Automatización IA</option>
                    <option value="chatbots">Chatbots Inteligentes</option>
                    <option value="sistemas-empresariales">Sistemas Empresariales</option>
                    <option value="marketing-ia">Marketing IA</option>
                    <option value="software-personalizado">Software Personalizado</option>
                    <option value="ciberseguridad">Ciberseguridad</option>
                    <option value="soporte-ti">Soporte TI</option>
                  </select>
                </div>

                {/* Message */}
                <div>
                  <label htmlFor="message" className="block text-sm font-semibold text-gray-300 mb-3">
                    Mensaje
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={5}
                    className="w-full px-4 py-3 rounded-lg bg-vanyx-gray/50 border border-vanyx-gray/80 text-white placeholder-gray-500 focus:outline-none focus:border-vanyx-cyan focus:ring-1 focus:ring-vanyx-cyan transition-all duration-300 resize-none"
                    placeholder="Cuéntanos más sobre tu proyecto..."
                  />
                </div>

                {/* Status message */}
                {submitStatus === 'success' && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-lg bg-green-500/20 border border-green-500/50 text-green-300 text-sm"
                  >
                    ✓ Mensaje enviado exitosamente. Nos contactaremos pronto.
                  </motion.div>
                )}

                {submitStatus === 'error' && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="p-4 rounded-lg bg-red-500/20 border border-red-500/50 text-red-300 text-sm"
                  >
                    ✗ Ocurrió un error. Por favor intenta nuevamente.
                  </motion.div>
                )}

                {/* Submit button */}
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  disabled={isSubmitting}
                  type="submit"
                  className="w-full px-6 py-4 rounded-lg font-semibold text-vanyx-black bg-vanyx-cyan hover:bg-vanyx-cyan-light disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300"
                >
                  {isSubmitting ? (
                    <motion.span
                      animate={{ opacity: [1, 0.5, 1] }}
                      transition={{ duration: 1.5, repeat: Infinity }}
                    >
                      Enviando...
                    </motion.span>
                  ) : (
                    'Enviar mensaje'
                  )}
                </motion.button>
              </form>
            </div>
          </motion.div>

          {/* Right side - Info and CTA */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="flex flex-col justify-between"
          >
            {/* Info box */}
            <div className="p-8 rounded-2xl border border-vanyx-gray/50 bg-gradient-to-br from-vanyx-gray/20 to-vanyx-black/50 backdrop-blur-xl mb-8">
              <h3 className="text-2xl font-bold text-white mb-6">¿Por qué elegir VANYX?</h3>

              <div className="space-y-4">
                {[
                  {
                    title: 'Respuesta Rápida',
                    description: 'Nos contactaremos en menos de 24 horas',
                  },
                  {
                    title: 'Consulta Gratuita',
                    description: 'Primera reunión sin costo para analizar tu proyecto',
                  },
                  {
                    title: 'Equipo Experto',
                    description: 'Profesionales con años de experiencia',
                  },
                  {
                    title: 'Soporte Continuo',
                    description: 'Acompañamiento durante todo el proyecto',
                  },
                ].map((item, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    className="flex gap-4"
                  >
                    <div className="flex-shrink-0 w-5 h-5 rounded-full bg-vanyx-cyan/20 border border-vanyx-cyan flex items-center justify-center mt-1">
                      <svg className="w-3 h-3 text-vanyx-cyan" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" />
                      </svg>
                    </div>
                    <div>
                      <h4 className="font-semibold text-white mb-1">{item.title}</h4>
                      <p className="text-sm text-gray-400">{item.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* WhatsApp CTA */}
            <motion.a
              href="https://wa.me/56912345678"
              target="_blank"
              rel="noopener noreferrer"
              whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(0, 217, 255, 0.4)' }}
              whileTap={{ scale: 0.95 }}
              className="p-8 rounded-2xl border border-vanyx-cyan/30 bg-gradient-to-br from-vanyx-cyan/10 to-transparent hover:from-vanyx-cyan/20 text-center transition-all duration-300"
            >
              <div className="text-5xl mb-4">💬</div>
              <h3 className="text-xl font-bold text-white mb-3">Chatea con nosotros</h3>
              <p className="text-gray-400 mb-4">
                Respuestas inmediatas en WhatsApp
              </p>
              <span className="inline-block px-6 py-3 rounded-lg font-semibold text-vanyx-black bg-vanyx-cyan hover:bg-vanyx-cyan-light transition-all">
                Abrir WhatsApp
              </span>
            </motion.a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
