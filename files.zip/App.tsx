'use client';

import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import ServicesSection from '@/components/ServicesSection';
import AboutSection from '@/components/AboutSection';
import PortfolioSection from '@/components/PortfolioSection';
import ContactSection from '@/components/ContactSection';
import Footer from '@/components/Footer';

export default function Home() {
  return (
    <main className="bg-vanyx-black text-white overflow-hidden">
      <Navigation />
      
      <section id="inicio">
        <HeroSection />
      </section>
      
      <section id="servicios">
        <ServicesSection />
      </section>
      
      <section id="sobre-nosotros">
        <AboutSection />
      </section>
      
      <section id="portafolio">
        <PortfolioSection />
      </section>
      
      <section id="contacto">
        <ContactSection />
      </section>
      
      <Footer />
    </main>
  );
}
