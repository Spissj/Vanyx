'use client';

import { motion } from 'framer-motion';
import React from 'react';

const services = [
  {
    id: 1,
    title: 'Desarrollo Web',
    description: 'Aplicaciones web modernas, rápidas y escalables con las últimas tecnologías.',
    icon: '🌐',
    color: 'from-vanyx-cyan to-blue-500',
  },
  {
    id: 2,
    title: 'Automatización IA',
    description: 'Sistemas inteligentes que automatizan tus procesos empresariales.',
    icon: '⚙️',
    color: 'from-purple-500 to-pink-500',
  },
  {
    id: 3,
    title: 'Chatbots Inteligentes',
    description: 'Asistentes virtuales potenciados por IA para tu atención al cliente.',
    icon: '💬',
    color: 'from-cyan-400 to-vanyx-cyan',
  },
  {
    id: 4,
    title: 'Sistemas Empresariales',
    description: 'Software personalizado diseñado para las necesidades de tu empresa.',
    icon: '🏢',
    color: 'from-orange-500 to-red-500',
  },
  {
    id: 5,
    title: 'Marketing IA',
    description: 'Estrategias de marketing potenciadas por inteligencia artificial.',
    icon: '📊',
    color: 'from-green-500 to-emerald-500',
  },
  {
    id: 6,
    title: 'Software Personalizado',
    description: 'Soluciones a medida que se adaptan perfectamente a tu negocio.',
    icon: '🎯',
    color: 'from-indigo-500 to-purple-500',
  },
  {
    id: 7,
    title: 'Ciberseguridad',
    description: 'Protección avanzada de tus datos y sistemas contra amenazas.',
    icon: '🔒',
    color: 'from-red-500 to-pink-500',
  },
  {
    id: 8,
    title: 'Soporte TI',
    description: 'Soporte técnico profesional disponible cuando lo necesites.',
    icon: '🛠️',
    color: 'from-yellow-500 to-orange-500',
  },
];

export default function ServicesSection() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const cardVariants = {
    hidden: { opacity: 0, y: 30 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: 'easeOut' },
    },
  };

  return (
    <section className="relative py-24 bg-vanyx-black overflow-hidden">
      {/* Background elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-0 left-1/3 w-96 h-96 bg-vanyx-cyan/5 rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-vanyx-cyan/5 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 mx-auto max-w-7xl px-6">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="mb-16 text-center"
        >
          <h2 className="text-5xl md:text-6xl font-bold text-white mb-6">
            Nuestros Servicios
          </h2>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            Soluciones integrales de tecnología para transformar tu negocio
          </p>
        </motion.div>

        {/* Services grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {services.map((service) => (
            <motion.div
              key={service.id}
              variants={cardVariants}
              whileHover={{
                y: -5,
                boxShadow: '0 0 30px rgba(0, 217, 255, 0.2)',
              }}
              className="group relative"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-vanyx-cyan/10 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 blur-xl" />

              <div className="relative h-full p-8 rounded-xl border border-vanyx-gray/50 bg-gradient-to-br from-vanyx-gray/30 to-vanyx-black/50 backdrop-blur-xl hover:border-vanyx-cyan/50 transition-all duration-300">
                {/* Icon */}
                <div className="mb-6 text-5xl">{service.icon}</div>

                {/* Content */}
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-vanyx-cyan transition-colors duration-300">
                  {service.title}
                </h3>

                <p className="text-sm text-gray-400 leading-relaxed mb-4">
                  {service.description}
                </p>

                {/* Accent line */}
                <motion.div
                  initial={{ width: 0 }}
                  whileHover={{ width: 40 }}
                  className="h-1 bg-gradient-to-r from-vanyx-cyan to-transparent rounded-full"
                />

                {/* Glow on hover */}
                <div className="absolute inset-0 rounded-xl bg-vanyx-cyan/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-20 text-center"
        >
          <p className="text-gray-400 mb-6">¿Necesitas una solución específica?</p>
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(0, 217, 255, 0.4)' }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 rounded-lg font-semibold text-vanyx-black bg-vanyx-cyan hover:bg-vanyx-cyan-light transition-all duration-300"
          >
            Contáctanos para una consulta
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
